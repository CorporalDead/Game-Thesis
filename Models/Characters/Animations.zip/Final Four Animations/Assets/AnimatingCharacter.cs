﻿using UnityEngine;
using System.Collections;

public class AnimatingCharacter : MonoBehaviour
{

	Animator playerAnim;

	bool leftWall, rightWall;

	// Use this for initialization
	void Start ()
	{
		leftWall = false;
		rightWall = true; //temporary true for testing
		playerAnim = GetComponent<Animator> ();
	}
	
	// Update is called once per frame
	void Update ()
	{
		float fb = Input.GetAxis ("Vertical");
		float lr = Input.GetAxis ("Horizontal");

		playerAnim.SetFloat ("FB", fb * .5f);
		playerAnim.SetFloat ("LR", lr * .5f);

		if (Input.GetKey (KeyCode.LeftShift)) {
			if (leftWall) {
				playerAnim.SetBool ("LWRun", true);
			}

			if (rightWall) {
				playerAnim.SetBool ("RWRun", true);
			}
		} else {
			playerAnim.SetBool ("LWRun", false);
			playerAnim.SetBool ("RWRun", false);
		}
	}
}
