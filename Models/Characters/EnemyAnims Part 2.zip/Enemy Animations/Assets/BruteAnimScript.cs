﻿using UnityEngine;
using System.Collections;

public class BruteAnimScript : MonoBehaviour
{

	Animator enemyAnim;

	bool guard, runBash, runBash2, attack;

	// Use this for initialization
	void Start ()
	{
		enemyAnim = GetComponent<Animator> ();
	}
	
	// Update is called once per frame
	void Update ()
	{
		float fb = Input.GetAxis ("Vertical");

		enemyAnim.SetFloat ("Running", fb * .5f);

		enemyAnim.SetBool ("Guard", guard);
		enemyAnim.SetBool ("Running Bash", runBash);
		enemyAnim.SetBool ("Running Bash 2", runBash2);
		enemyAnim.SetBool ("Attack", attack);
	}
}
