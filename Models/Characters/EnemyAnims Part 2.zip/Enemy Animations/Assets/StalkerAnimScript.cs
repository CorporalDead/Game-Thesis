﻿using UnityEngine;
using System.Collections;

public class StalkerAnimScript : MonoBehaviour {

	Animator enemyAnim;

	bool standingDSAttack, doubleLRAttack, runLSAttack, runRSAttack, leftLRAttack, RightLRAttack;

	// Use this for initialization
	void Start () {
		enemyAnim = GetComponent<Animator> ();
	}
	
	// Update is called once per frame
	void Update () {
		enemyAnim.SetBool ("Standing Double Slash Attack", standingDSAttack);
		enemyAnim.SetBool ("Double Long Range Attack", doubleLRAttack);
		enemyAnim.SetBool ("Run Left Slash Attack", runLSAttack);
		enemyAnim.SetBool ("Run Right Slash Attack", runRSAttack);
		enemyAnim.SetBool ("Left Long Range Attack", leftLRAttack);
		enemyAnim.SetBool ("Right Long Range Attack", RightLRAttack);
	}
}
