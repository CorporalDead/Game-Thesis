﻿using UnityEngine;
using System.Collections;

public class SS_Gol_Animation : MonoBehaviour {

	Animator SSGolAnimator;
	CharacterController playerCont;

	// Use this for initialization
	void Start () {

		SSGolAnimator = GetComponent<Animator>();
		playerCont = GetComponent<CharacterController> ();
	
	}
	
	// Update is called once per frame
	void Update () {

		SSGolAnimator.SetBool ("Fire", false);

		//Walk Front and Back
		float ForwardBackward = Input.GetAxis ("Vertical");
		SSGolAnimator.SetFloat ("RFRB", -ForwardBackward);

		//Walk Left and Right
		float LeftRight = Input.GetAxis ("Horizontal");
		SSGolAnimator.SetFloat ("RLRR", LeftRight);


		playerCont.Move (transform.TransformDirection (new Vector3 (-ForwardBackward, 0, LeftRight)));


		//Fire
		bool checkFire = false;
		if (Input.GetButtonDown ("Fire1")) {

			checkFire = true;
			SSGolAnimator.SetBool ("Fire", checkFire);

		} 

		//Full reload
		bool checkReload = false;
		if (Input.GetKeyDown (KeyCode.R) && SSGolAnimator.GetCurrentAnimatorStateInfo(0).IsName("FullReload")) {

			checkReload = true;
			SSGolAnimator.SetBool ("FullReload", checkReload);

		} else {

			checkReload = false;
			SSGolAnimator.SetBool ("FullReload", checkReload);
		}
	
	}
}
